import logging

logging.basicConfig(level=logging.INFO)
logging.info("Starting the robot system...")