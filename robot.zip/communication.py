import requests

def send_alert(message):
    api_url = "https://example.com/alert"
    payload = {"message": message}
    response = requests.post(api_url, json=payload)
    return response.status_code