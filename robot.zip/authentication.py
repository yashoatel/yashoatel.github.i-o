from adafruit_fingerprint import Adafruit_Fingerprint

def enroll_fingerprint(fingerprint_sensor):
    print("Place your finger on the sensor...")
    while fingerprint_sensor.get_image() != Adafruit_Fingerprint.OK:
        pass
    print("Image taken!")
    # Additional steps for enrollment