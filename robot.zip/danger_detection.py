import cv2
import tensorflow as tf

# Load pre-trained model
model = tf.keras.models.load_model("danger_detection_model.h5")

def detect_danger(frame):
    # Preprocess the frame
    resized_frame = cv2.resize(frame, (224, 224))
    input_data = resized_frame / 255.0
    input_data = input_data.reshape(1, 224, 224, 3)
    # Predict
    prediction = model.predict(input_data)
    return "Danger" if prediction[0][0] > 0.5 else "Safe"